from __future__ import annotations


class PoetryException(Exception):
    pass


class InvalidProjectFile(PoetryException):
    pass
