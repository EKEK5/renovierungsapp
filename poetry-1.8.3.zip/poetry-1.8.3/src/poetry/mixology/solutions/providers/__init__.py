from __future__ import annotations

from poetry.mixology.solutions.providers.python_requirement_solution_provider import (
    PythonRequirementSolutionProvider,
)


__all__ = ["PythonRequirementSolutionProvider"]
