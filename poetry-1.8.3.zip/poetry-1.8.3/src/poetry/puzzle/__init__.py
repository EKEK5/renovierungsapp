from __future__ import annotations

from poetry.puzzle.solver import Solver


__all__ = ["Solver"]
