from __future__ import annotations

import pytest


pytest.register_assert_rewrite("tests.mixology.helpers")
